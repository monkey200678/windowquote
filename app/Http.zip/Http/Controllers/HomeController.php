<?php

namespace App\Http\Controllers;

use App\Models\Bio;
use App\Models\CalcValues;
use App\Models\Director;
use App\Models\Locations;
use App\Models\Movie;
use App\Models\Studio;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        Session::flush();
        $locations = Locations::orderBy('abbr_name')->get();
        return view('frontend.home', compact('locations'));
    }

    public function mainCalc(Request $request, $initialize)
    {
        if($initialize == 1){
            Session::forget('calcList');
        }
        
        $location = $request->input('location') ?? '1';
        Session::put('location', $location);

        return view('frontend.main-calc');
    }

    public function individualSecond(Request $request, $calc_type) {

        if(!(session::has('width') && session::has('height'))) {
            $width = $request->input('width');
            $height = $request->input('height');
            Session::put('width', $width);
            Session::put('height', $height);
        }

        return view('frontend.individual-calc-second', compact('calc_type'));
    }

    public function individualFourth(Request $request, $win_type) {  
        if($request->input('window_type')) {
            $win_type = $request->input('window_type');
            if($win_type[strlen($win_type)-1]==='T') {
                session::put('interior_color', 'tan');
                session::put('exterior_color', 'tan');
            }
            elseif($win_type[strlen($win_type)-1]==='B') {
                session::put('interior_color', 'white');
                session::put('exterior_color', 'black');
            }
            elseif($win_type[strlen($win_type)-1]==='W') {
                session::put('interior_color', 'white');
                session::put('exterior_color', 'white');
            }
            elseif($win_type[strlen($win_type)-1]==='G' && $win_type[strlen($win_type)-3]==='W') {
                session::put('interior_color', 'white');
                session::put('exterior_color', 'white');
            }
            elseif($win_type[strlen($win_type)-1]==='G' && $win_type[strlen($win_type)-3]==='B') {
                session::put('interior_color', 'white');
                session::put('exterior_color', 'black');
            }
            elseif($win_type[strlen($win_type)-1]==='G' && $win_type[strlen($win_type)-3]==='T') {
                session::put('interior_color', 'tan');
                session::put('exterior_color', 'tan');
            }
            Session::put('win_type', $win_type);
        }
        else {
            Session::put('win_type', $win_type);                                                                                                                                                                                                                                                    
        }        
        return view('frontend.individual-calc-fourth', compact('win_type'));
    }

    public function individualFifth(Request $request) {
        $glass = $request->input('glass-demo');
        $win_type = $request->input('win_type');
        $foam_field = $request->input('foam_field');
        
        Session::put('glass', $glass);
        Session::put('win_type', $win_type);
        Session::put('foam_field', $foam_field);
        return view('frontend.individual-calc-fifth', compact('win_type'));    
    }

    public function individualFinal(Request $request) {
        $qty = $request->input('qty');
        $standard = $request->input('standard-install');
        $warranty = $request->input('standard-warranty');
        Session::put('qty', $qty);
        return view('frontend.individual-calc-final', compact(['standard', 'warranty']));
    }

    public function subCalc($calc_type)
    {
        return view('frontend.sub-calc', compact('calc_type'));
    }

    public function individualCalc($calc_type)
    {
        return view('frontend.individual-calc', compact(['calc_type']));
    }

    public function individualThird(Request $request) {

        $win_type = $request->input('value');

        return view('frontend.individual-calc-third')->with('win_type', $win_type);
    }

    public function result(Request $request)
    {
        $total_price = 0;
        $location = Session::get('location') ?? '1';
        $calc_type = $request->input('calc_type');
        $width = $request->input('width'); 
        $height = $request->input('height');
        $outside_color = $request->input('outside_color');
        $inside_color = $request->input('inside_color');
        $thickness = $request->input('thickness');
        $privacy_panel = $request->input('privacy_panel'); 
        $center_pattern = $request->input('center_pattern');
        $top_pattern = $request->input('top_pattern');
        $bottom_pattern = $request->input('bottom_pattern');
        $warranty = $request->input('warranty');
        $quantity = $request->input('quantity');
        if($calc_type !== 'sd') {
            $total_size = $width + $height;
        }
        else {
            $total_size = $width;
        }

        $data = CalcValues::where([
            'calc_type' => $calc_type,
            'total_size' => $total_size
        ])->first();

        $rowCount = CalcValues::where([
            'calc_type' => $calc_type,
            'total_size' => $total_size
        ])->count();

        if($rowCount >= 1){
            $total_price += $data->base_price;

            if($outside_color == 'black' || $outside_color == 'beige'){
                $total_price += $data->outside_color_price;
            }

            if($inside_color == 'black' || $inside_color == 'beige'){
                $total_price += $data->inner_color_price;
            }

            $total_price += $data->thickness_color_price;


            if($calc_type == 'bac')
            {
                if($center_pattern == 'yes'){
                    $total_price += $data->center_pattern_price;
                }

                if($top_pattern == 'yes'){
                    $total_price += $data->top_pattern_price;
                }
            }
            else if ($calc_type == 'badh')
            {
                if($center_pattern == 'yes'){
                    $total_price += $data->center_pattern_price;
                }

                if($top_pattern != 0){
                    $total_price += $data->top_pattern_price;
                }

                if($bottom_pattern != 0){
                    $total_price += $data->bottom_pattern_price;
                }

            }
            else if ($calc_type == 'dh')
            {
                if($top_pattern != 0){
                    $total_price += $data->top_pattern_price;
                }

                if($bottom_pattern != 0){
                    $total_price += $data->bottom_pattern_price;
                }
            }
            else
            {
                if($center_pattern == 'yes'){
                    $total_price += $data->center_pattern_price;
                }
            }

            if($privacy_panel == 'yes'){
                $total_price += $data->privacy_panel_price;
            }

            if($warranty == 'yes'){
                $total_price += $data->extra_warranty_price;
            }

            $locationVal = Locations::where('id', $location)->value('percentage');

            if($locationVal != 0){
                $total_price = $total_price + ($total_price / 100 * $locationVal);
            }

            $total_price = $total_price * $quantity;

            $sum = 0; $calcList = '';
            if(Session::has('calcList'))
            {
                $calcList = json_decode(\Illuminate\Support\Facades\Session::get('calcList'));

                $tempArray = array(
                    'calc_type' =>$calc_type,
                    'total_price' => $total_price,
                    'width' => $width,
                    'height' => $height,
                    'quantity' => $quantity,
                    'outside_color' => $outside_color,
                    'inside_color' => $inside_color,
                    'warranty' => $warranty,
                    'thickness' => $thickness,
                    'privacy_panel' => $privacy_panel,
                    'center_pattern' => $center_pattern,
                    'top_pattern' => $top_pattern,
                    'bottom_pattern' => $bottom_pattern,
                );

                //check if width, height, calc type is same
                foreach ($calcList as $key=>$val){
                    if ($val->calc_type == $calc_type && $val->width == $width && $val->height == $height){
                        $val->total_price += $total_price;
                        $val->quantity += $quantity;
                    }
                }

                if(  array_search($calc_type, array_column($calcList, 'calc_type'))!== FALSE
                    && array_search($width, array_column($calcList, 'width'))!== FALSE
                    && array_search($height, array_column($calcList, 'height'))!== FALSE)
                {

                }else{
                    array_push($calcList, $tempArray);
                    $calcList = json_decode(json_encode($calcList));
                }

                foreach ($calcList as $val){
                    $sum+=$val->total_price;
                }
            }
            return view('frontend.result', compact('calcList', 'sum','calc_type', 'total_price', 'width', 'height', 'quantity','outside_color', 'inside_color', 'warranty', 'thickness', 'privacy_panel', 'top_pattern', 'center_pattern', 'bottom_pattern'));

        }else{
            $minValue = CalcValues::where('calc_type', $calc_type)->min('total_size');
            $maxValue = CalcValues::where('calc_type', $calc_type)->max('total_size');
            return redirect()->back()->with(['flash_error' => 'Size is not available']);
        }

    }

    public function addMore(Request $request)
    {
        $calc_type = $request->input('calc_type');
        $total_price = $request->input('total_price');
        $width = $request->input('width');
        $height = $request->input('height');
        $quantity = $request->input('quantity');
        $warranty = $request->input('warranty');
        $inside_color = $request->input('inside_color');
        $outside_color = $request->input('outside_color');
        $thickness = $request->input('thickness');
        $privacy_panel = $request->input('privacy_panel');
        $center_pattern = $request->input('center_pattern');
        $top_pattern = $request->input('top_pattern');
        $bottom_pattern = $request->input('bottom_pattern');
        
        //store calc type and total price to the session
        $this->setCalcList($quantity, $calc_type, $total_price, $width, $height, $outside_color, $inside_color, $thickness, $warranty, $privacy_panel, $center_pattern, $top_pattern, $bottom_pattern);

        return redirect()->route('front.main-calc', $initialize = 0);
    }

    private function setCalcList($quantity, $calc_type, $total_price, $width, $height, $outside_color, $inside_color, $thickness, $warranty, $privacy_panel, $center_pattern, $top_pattern, $bottom_pattern)
    {
        if(session('calcList') == null) {
            $originalValue = array();
        }else{
            $originalValue = json_decode(session('calcList'));
        }

        $tempArray = array(
            'calc_type' =>$calc_type,
            'total_price' => $total_price,
            'width' => $width,
            'height' => $height,
            'quantity' => $quantity,
            'outside_color' => $outside_color,
            'inside_color' => $inside_color,
            'thickness' => $thickness,
            'warranty' => $warranty,
            'privacy_panel'=>$privacy_panel,
            'top_pattern'=>$top_pattern,
            'center_pattern'=>$center_pattern,
            'bottom_pattern'=>$bottom_pattern
        );

        //check if width, height, calc type is same
        foreach ($originalValue as $key=>$val){
            if ($val->calc_type == $calc_type && $val->width == $width && $val->height == $height) {
                $val->total_price += $total_price;
                $val->quantity += $quantity;
            }
        }

        //if specific value exist or not in the array
        if(  array_search($calc_type, array_column($originalValue, 'calc_type'))!== FALSE
            && array_search($width, array_column($originalValue, 'width'))!== FALSE
            && array_search($height, array_column($originalValue, 'height'))!== FALSE )
        {
            $calcList = json_encode($originalValue);
        }
        else {
            array_push($originalValue, $tempArray);
            $calcList = json_encode($originalValue);
        }

        Session::put('calcList', $calcList);
        Session::put('height', $height);
        Session::put('width', $width);
        Session::put('outside_color', $outside_color);
        Session::put('inside_color', $inside_color);
        Session::put('warranty', $warranty);
        Session::put('thickness', $thickness);
        Session::put('privacy_panel', $privacy_panel);
        Session::put('top_pattern', $top_pattern);
        Session::put('center_pattern', $center_pattern);
        Session::put('bottom_pattern', $bottom_pattern);
    }

    public function checkOut(Request $request)
    {
        return view('frontend.checkout');
    }
}
